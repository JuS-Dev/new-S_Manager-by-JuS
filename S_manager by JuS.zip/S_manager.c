#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>



//Used macro
#define MAX_YR  9999
#define MIN_YR  1900
#define MAX_SIZE_USER_NAME 30
#define MAX_SIZE_PASSWORD  20
#define FILE_NAME  "StudentRecordSystemByJuS.bin"
// Macro related to the students info
#define MAX_FATHER_NAME 50
#define MAX_STUDENT_NAME 50
#define MAX_STUDENT_ADDRESS 300
#define MAX_SIZE_SCHOOL_SUBJECTS_SCORE 1
#define MAX_SIZE_MALE_FEMALE 7
#define FILE_HEADER_SIZE  sizeof(sFileHeader)

typedef struct
{
    char username[MAX_SIZE_USER_NAME];
    char password[MAX_SIZE_PASSWORD];
} sFileHeader;


//Elements of structure
typedef struct// to call in program
{
    unsigned int student_id; // declare the integer data type
    char fatherName[MAX_FATHER_NAME];// declare the charecter data type
    char studentName[MAX_STUDENT_NAME];// declare the character data type
    char studentAddr[MAX_STUDENT_ADDRESS];// declare the character data type
    char sex [MAX_SIZE_MALE_FEMALE]; // declare the character data type
    int ForeignLanguage ; // declare the integer data type
    int Chinese ; // declare the integer data type
    int Math; // declare the integer data type
    int Physics; // declare the integer data type
    int C ; // declare the integer data type
    float totalScore ; // declare the float data type
    float averageScore ; // declare the float data type
} s_StudentInfo;

//Align the message
void printMessageCenter(const char* message)
{
    int len =0;
    int pos = 0;
    //calculate how many space need to print
    len = (78 - strlen(message))/2;
    printf("\t\t\t");
    for(pos =0 ; pos < len ; pos++)
    {
        //print space
        printf(" ");
    }
    //print message
    printf("%s",message);
}

//Head message
void headMessage(const char *message)
{
    system("cls");
    printf("\n\t\t\t###########################################################################");
    printf("\n\t\t\t############                                                   ############");
    printf("\n\t\t\t############   Student Record Management System Project in C   ############");
    printf("\n\t\t\t############                                                   ############");
    printf("\n\t\t\t###########################################################################");
    printf("\n\t\t\t---------------------------------------------------------------------------\n");
    printMessageCenter(message);
    printf("\n\t\t\t----------------------------------------------------------------------------");

}

//Display message
void welcomeMessage()
{
    headMessage("199022@stu.hebut.edu.cn");
    printf("\n\n\n\n\n");
    printf("\n\t\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
    printf("\n\t\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t\t        =                  WELCOME                 =");
    printf("\n\t\t\t\t        =                     TO                    =");
    printf("\n\t\t\t\t        =               Student Record              =");
    printf("\n\t\t\t\t        =                 MANAGEMENT                =");
    printf("\n\t\t\t\t        =                   SYSTEM                  =");
    printf("\n\t\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
    printf("\n\n\n\t\t\t Enter any key to continue.....");
    getchar();
}

//Validate name
int isNameValid(const char *name)
{
    int validName = 1;
    int len = 0;
    int index = 0;
    len = strlen(name);
    for(index =0; index <len ; ++index)
    {
        if(!(isalpha(name[index])) && (name[index] != '\n') && (name[index] != ' '))
        {
            validName = 0;
            break;
        }
    }
    return validName;
}
// Validate score no more than 100 score
int isScoreValid( unsigned int Score[])
{
    int validScore = 1;
    int Min = 0;
    int Max = 100;
    if(Score[0] < Min ) validScore = 0;
    if(Score[0] > Max ) validScore = 0;
    return validScore;
}
//

/*calculate how many students in list but it is not working properly
void Student_Cont(int student_add_or_delete)
{
    FILE *fp = NULL;
    if ((fp=fopen(FILE_NAME, "wb"))==NULL) {
    printf("Cannot open file.\n");
    exit (1);
    }
    int total_Student_count = total_Student_count;
    total_Student_count += student_add_or_delete;
    fwrite(&total_Student_count, sizeof(int), 1, fp);
    fclose (fp);
} */
// Add student in list
void addStudentInDataBase()
{
    s_StudentInfo addStudentInfoInDataBase = {0};

    FILE *fp = NULL;
    int status = 0;
    fp = fopen(FILE_NAME,"ab+");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    headMessage("ADD NEW Students");
    printf("\n\n\t\t\tENTER YOUR DETAILS BELOW:");
    printf("\n\t\t\t---------------------------------------------------------------------------\n");
    printf("\n\t\t\tStudent ID  = ");
    fflush(stdin);
    scanf("%u",&addStudentInfoInDataBase.student_id);
    do
    {
        printf("\n\t\t\tStudent Name  = ");
        fflush(stdin);
        fgets(addStudentInfoInDataBase.studentName,MAX_FATHER_NAME,stdin);
        status = isNameValid(addStudentInfoInDataBase.studentName);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please Enter again.");
        }
    }
    while(!status);
    do
    {
        printf("\n\t\t\tFather Name  = ");
        fflush(stdin);
        fgets(addStudentInfoInDataBase.fatherName,MAX_STUDENT_NAME,stdin);
        status = isNameValid(addStudentInfoInDataBase.fatherName);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please Enter again.");
        }
    }
    while(!status);
    do
    {
        printf("\n\t\t\tSex (Male/Female) = ");
        fflush(stdin);
        fgets(addStudentInfoInDataBase.sex,MAX_SIZE_MALE_FEMALE,stdin);
        status = isNameValid(addStudentInfoInDataBase.sex);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please Enter again.");
        }
    }
    while(!status);
    do
    {
        printf("\n\t\t\tStudent Address  = ");
        fflush(stdin);
        fgets(addStudentInfoInDataBase.studentAddr,MAX_FATHER_NAME,stdin);
        status = isNameValid(addStudentInfoInDataBase.studentAddr);
        if (!status)
        {
            printf("\n\t\t\tName contain invalid character. Please enter again.");
        }
    }
    while(!status);
     do
    {
        printf("\n\t\t\tStudent Score Foreign Language  = ");
        fflush(stdin);
        scanf("%d",&addStudentInfoInDataBase.ForeignLanguage);
        status = isScoreValid(&addStudentInfoInDataBase.ForeignLanguage);
        if (status == 0)
        {
            printf("\n\t\t\tScore Contain invalid Number. Please enter again.");
        }
    }
    while(status != 1);
     do
    {
        printf("\n\t\t\tStudent Score Chinese  = ");
        fflush(stdin);
        scanf("%d",&addStudentInfoInDataBase.Chinese);
        status = isScoreValid(&addStudentInfoInDataBase.Chinese);
        if (status == 0)
        {
            printf("\n\t\t\tScore Contain invalid Number. Please enter again.");
        }
    }
    while(status != 1);
     do
    {
        printf("\n\t\t\tStudent Score Math  = ");
        fflush(stdin);
        scanf("%d",&addStudentInfoInDataBase.Math);
        status = isScoreValid(&addStudentInfoInDataBase.Math);
        if (status == 0)
        {
            printf("\n\t\t\tScore Contain invalid Number. Please enter again.");
        }
    }
    while(status != 1);
     do
    {
        printf("\n\t\t\tStudent Score Physics  = ");
        fflush(stdin);
        scanf("%d",&addStudentInfoInDataBase.Physics);
        status = isScoreValid(&addStudentInfoInDataBase.Physics);
        if (status == 0)
        {
            printf("\n\t\t\tScore Contain invalid Number. Please Enter gain.");
        }
    }
    while(status != 1);

    do
    {
        printf("\n\t\t\tStudent Score C programming  = ");
        fflush(stdin);
        scanf("%d",&addStudentInfoInDataBase.C);
        status = isScoreValid(&addStudentInfoInDataBase.C);
        if (status == 0)
        {
            printf("\n\t\t\tScore Contain invalid Number. Please enter again.");
        }
    }
    while(status != 1);
    addStudentInfoInDataBase.averageScore = (addStudentInfoInDataBase.ForeignLanguage + addStudentInfoInDataBase.Chinese + addStudentInfoInDataBase.Math + addStudentInfoInDataBase. Physics + addStudentInfoInDataBase.C )/5 ;
    addStudentInfoInDataBase.totalScore = addStudentInfoInDataBase.ForeignLanguage + addStudentInfoInDataBase.Chinese + addStudentInfoInDataBase.Math + addStudentInfoInDataBase. Physics + addStudentInfoInDataBase.C;

    fwrite(&addStudentInfoInDataBase,sizeof(addStudentInfoInDataBase), 1, fp);
    fclose(fp);
    printf("\n\t\t\tStudent Info Successfully Added ");

}


// search student
void searchStudent()
{
    int found = 0;
    int studentId =0;
    s_StudentInfo addStudentInfoInDataBase = {0};
    FILE *fp = NULL;
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("\n\t\t\tFile is not opened\n");
        exit(1);
    }
    headMessage("SEARCH STUDENTS");
    //put the control on student detail
    if (fseek(fp,FILE_HEADER_SIZE,SEEK_SET) != 0)
    {
        fclose(fp);
        printf("\n\t\t\tFacing issue while reading file\n");
        exit(1);
    }
    printf("\n\n\t\t\tEnter Student ID Number to search:");
    fflush(stdin);
    scanf("%u",&studentId);
    while (fread (&addStudentInfoInDataBase, sizeof(addStudentInfoInDataBase), 1, fp))
    {
        if(addStudentInfoInDataBase.student_id == studentId)
        {
            found = 1;
            break;
        }
    }
    if(found)
    {
        printf("\n\t\t\tStudent id = %d\n",addStudentInfoInDataBase.student_id);
        printf("\n\t\t\tStudent name = %s\n",addStudentInfoInDataBase.studentName);
        printf("\t\t\tFather Name = %s\n",addStudentInfoInDataBase.fatherName);
        printf("\n\t\t\tSex = %s\n",addStudentInfoInDataBase.sex);
        printf("\n\t\t\tStudent Address = %s\n",addStudentInfoInDataBase.studentAddr);
        printf("\n\t\t\tForeign Language Score = %d\n",addStudentInfoInDataBase.ForeignLanguage);
        printf("\n\t\t\tChinese Score = %d\n",addStudentInfoInDataBase.Chinese);
        printf("\n\t\t\tMath Score = %d\n",addStudentInfoInDataBase.Math);
        printf("\n\t\t\tPhysics Score = %d\n",addStudentInfoInDataBase.Physics);
        printf("\n\t\t\tC Score = %d\n",addStudentInfoInDataBase.C);
        printf("\n\t\t\tAverage Score = %.2f\n",addStudentInfoInDataBase.averageScore);
        printf("\n\t\t\tTotal Score = %.2f\n",addStudentInfoInDataBase.totalScore);

    }
    else
    {
        printf("\n\t\t\tNo Record");
    }
    fclose(fp);
    printf("\n\n\n\t\t\tPress any key to go to main menu.....");
    fflush(stdin);
    getchar();
}


// view students function
void viewStudent()
{
    int found = 0;
    s_StudentInfo addStudentInfoInDataBase = {0};
    FILE *fp = NULL;
    unsigned int countStudent = 1;
    headMessage("VIEW STUDENT DETAILS");
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    if (fseek(fp,FILE_HEADER_SIZE,SEEK_SET) != 0)
    {
        fclose(fp);
        printf("Facing issue while reading file\n");
        exit(1);
    }
    while (fread (&addStudentInfoInDataBase, sizeof(addStudentInfoInDataBase), 1, fp))
    {
        printf("\n\t\t\tStudent id = %d\n",addStudentInfoInDataBase.student_id);
        printf("\n\t\t\tStudent name = %s\n",addStudentInfoInDataBase.studentName);
        printf("\t\t\tFather Name = %s\n",addStudentInfoInDataBase.fatherName);
        printf("\n\t\t\tSex = %s",addStudentInfoInDataBase.sex);
        printf("\n\t\t\tStudent Address = %s\n",addStudentInfoInDataBase.studentAddr);
        printf("\n\t\t\tForeign Language Score = %d\n",addStudentInfoInDataBase.ForeignLanguage);
        printf("\n\t\t\tChinese Score = %d\n",addStudentInfoInDataBase.Chinese);
        printf("\n\t\t\tMath Score = %d\n",addStudentInfoInDataBase.Math);
        printf("\n\t\t\tPhysics Score = %d\n",addStudentInfoInDataBase.Physics);
        printf("\n\t\t\tC Score = %d\n",addStudentInfoInDataBase.C);
        printf("\n\t\t\tAverage Score = %.2f\n",addStudentInfoInDataBase.averageScore);
        printf("\n\t\t\tTotal Score = %.2f\n",addStudentInfoInDataBase.totalScore);
        printf("\n\t\t\t---------------------------------------------------------------------------\n");
    }
    fclose(fp);
    if(!found)
    {
        printf("\n\t\t\tNo Record");
    }
    printf("\n\n\t\t\tPress any key to go to main menu.....");
    fflush(stdin);
    getchar();
}


// Delete student entry
void deleteStudent()
{
    int found = 0;
    int studentDelete = 0;
    sFileHeader fileHeaderInfo = {0};
    s_StudentInfo addStudentInfoInDataBase = {0};
    FILE *fp = NULL;
    FILE *tmpFp = NULL;
    headMessage("Delete Student Details");
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    tmpFp = fopen("tmp.bin","wb");
    if(tmpFp == NULL)
    {
        fclose(fp);
        printf("File is not opened\n");
        exit(1);
    }
    fread (&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
    fwrite(&fileHeaderInfo,FILE_HEADER_SIZE, 1, tmpFp);
    printf("\n\t\t\tEnter Student ID Number for delete:");
    scanf("%d",&studentDelete);
    while (fread (&addStudentInfoInDataBase, sizeof(addStudentInfoInDataBase), 1, fp))
    {
        if(addStudentInfoInDataBase.student_id != studentDelete)
        {
            fwrite(&addStudentInfoInDataBase,sizeof(addStudentInfoInDataBase), 1, tmpFp);
        }
        else
        {
            found = 1;
        }
    }
    (found)? printf("\n\t\t\tRecord deleted successfully....."):printf("\n\t\t\tRecord not found");
    fclose(fp);
    fclose(tmpFp);
    remove(FILE_NAME);
    rename("tmp.bin",FILE_NAME);
}

//function to update credential
void updateCredential(void)
{
    sFileHeader fileHeaderInfo = {0};
    FILE *fp = NULL;
    unsigned char userName[MAX_SIZE_USER_NAME] = {0};
    unsigned char password[MAX_SIZE_PASSWORD] = {0};
    headMessage("Update Credential");
    fp = fopen(FILE_NAME,"rb+");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    fread (&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
    if (fseek(fp,0,SEEK_SET) != 0)
    {
        fclose(fp);
        printf("\n\t\t\tFacing issue while updating password\n");
        exit(1);
    }
    printf("\n\n\t\t\tNew Username:");
    fflush(stdin);
    fgets(userName,MAX_SIZE_USER_NAME,stdin);
    printf("\n\n\t\t\tNew Password:");
    fflush(stdin);
    fgets(password,MAX_SIZE_PASSWORD,stdin);
    strncpy(fileHeaderInfo.username,userName,sizeof(userName));
    strncpy(fileHeaderInfo.password,password,sizeof(password));
    fwrite(&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
    fclose(fp);
    printf("\n\t\t\tYour Password has been changed successfully");
    printf("\n\t\t\ttLogin Again:");
    fflush(stdin);
    getchar();
    exit(1);
}

//Display menu
void menu()
{
    int Choice = 0;
    do
    {
        headMessage("MAIN MENU");
        printf("\n\n\n\t\t\t1.Add Student");
        printf("\n\t\t\t2.Search Student");
        printf("\n\t\t\t3.View Student");
        printf("\n\t\t\t4.Delete Student");
        printf("\n\t\t\t5.Update Password");
        printf("\n\t\t\t0.Exit");
        printf("\n\n\n\t\t\tEnter choice => ");
        scanf("%d",&Choice);
        switch(Choice)
        {
        case 1:
            addStudentInDataBase();
            //Student_Cont(1);
            break;
        case 2:
            searchStudent();
            break;
        case 3:
            viewStudent();
            break;
        case 4:
            deleteStudent();
            //Student_Cont(-1);
            break;
        case 5:
            updateCredential();
            break;
        case 0:
            printf("\n\n\n\t\t\t\tThank you!!!\n\n\n\n\n");
            exit(1);
            break;
        default:
            printf("\n\n\n\t\t\tINVALID INPUT!!! Try again...");
        }                                            //Switch Ended
    }
    while(Choice!=0);                                        //Loop Ended
}
/*Display menu    here I tried to make a string input ` but too many errors ( I spent 3 days, something achieved but in the end ( ┬ ┬ ﹏ ┬ ┬ )     )
void menu()
{

    char *choiceINstring;
    choiceINstring = (char*)malloc(10);
    do
    {
        headMessage("MAIN MENU");
        printf("\n\n\n\t\t\t1.Add Student");
        printf("\n\t\t\t2.Search Student");
        printf("\n\t\t\t3.View Student");
        printf("\n\t\t\t4.Delete Student");
        printf("\n\t\t\t5.Update Password");
        printf("\n\t\t\t0.Exit");
        printf("\n\n\n\t\t\tEnter choice => ");
        gets(choiceINstring);
        strlwr(choiceINstring); // Convert to lowercase
        if (!strcmp(choiceINstring ,'1'))addStudentInDataBase();
        if (!strcmp(choiceINstring ,'2'))searchStudent();
        if (!strcmp(choiceINstring ,'3'))viewStudent();
        if (!strcmp(choiceINstring ,'4'))deleteStudent();
        if (!strcmp(choiceINstring ,'5'))updateCredential();
        if (!strcmp(choiceINstring ,"add"))addStudentInDataBase();
        if (!strcmp(choiceINstring ,"search"))searchStudent();
        if (!strcmp(choiceINstring ,"view"))viewStudent();
        if (!strcmp(choiceINstring ,"delete"))deleteStudent();
        if (!strcmp(choiceINstring ,"update"))updateCredential();

    }
    while(choiceINstring != '0');                                        //Loop Ended
} */


//login password
void login()
{
    unsigned char userName[MAX_SIZE_USER_NAME] = {0};
    unsigned char password[MAX_SIZE_PASSWORD] = {0};
    int L=0;
    sFileHeader fileHeaderInfo = {0};
    FILE *fp = NULL;
    headMessage("Login");
    fp = fopen(FILE_NAME,"rb");
    if(fp == NULL)
    {
        printf("File is not opened\n");
        exit(1);
    }
    fread (&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
    fclose(fp);
    do
    {
        printf("\n\n\n\t\t\t\tUsername:");
        fgets(userName,MAX_SIZE_USER_NAME,stdin);
        printf("\n\t\t\t\tPassword:");
        fgets(password,MAX_SIZE_PASSWORD,stdin);
        if((!strcmp(userName,fileHeaderInfo.username)) && (!strcmp(password,fileHeaderInfo.password)))
        {
            menu();
        }
        else
        {
            printf("\t\t\t\tLogin Failed Enter Again Username & Password\n\n");
            L++;
        }
    }
    while(L<=3);
    if(L>3)
    {
        headMessage("Login Failed");
        printf("\t\t\t\tSorry,Unknown User.");
        getchar();
        system("cls");
    }
}

//Check file exist or not
int isFileExists(const char *path)
{
    // Try to open file
    FILE *fp = fopen(path, "rb");
    int status = 0;
    // If file does not exists
    if (fp != NULL)
    {
        status = 1;
        // File exists hence close file
        fclose(fp);
    }
    return status;
}

void init()
{
    FILE *fp = NULL;
    int status = 0;
    const char defaultUsername[] ="JuS\n";
    const char defaultPassword[] ="hebut\n";
    sFileHeader fileHeaderInfo = {0};
    status = isFileExists(FILE_NAME);
    if(!status)
    {
        //create the binary file
        fp = fopen(FILE_NAME,"wb");
        if(fp != NULL)
        {
            //Copy default password
            strncpy(fileHeaderInfo.password,defaultPassword,sizeof(defaultPassword));
            strncpy(fileHeaderInfo.username,defaultUsername,sizeof(defaultUsername));
            fwrite(&fileHeaderInfo,FILE_HEADER_SIZE, 1, fp);
            fclose(fp);
        }
    }
}
int main()
{
    init();//initialize
    welcomeMessage();
    login();
    return 0;
}
